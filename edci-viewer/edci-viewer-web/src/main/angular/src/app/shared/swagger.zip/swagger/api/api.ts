export * from './v1.service';
import { V1Service } from './v1.service';
export const APIS = [V1Service];
